setwd("C:\\Users\\CHAMA COMPUTERS\\OneDrive\\Desktop\\IT24100263")

# 1. Generate a random sample of size 25
set.seed(123)   # for reproducibility
sample_data <- rnorm(25, mean = 45, sd = 2)
print(sample_data)

# 2. Perform hypothesis test
# H0 - mu = 46
# H1 - mu < 46  (left-tailed test)

t_test_result <- t.test(sample_data, mu = 46, alternative = "less")

# Show full test result
print(t_test_result)

# Extract key values
test_statistic <- t_test_result$statistic
p_value <- t_test_result$p.value
confidence_interval <- t_test_result$conf.int
sample_mean <- mean(sample_data)

cat("Sample Mean: ", sample_mean, "\n")
cat("Test Statistic (t): ", test_statistic, "\n")
cat("P-value: ", p_value, "\n")
cat("95% Confidence Interval: ", confidence_interval, "\n")